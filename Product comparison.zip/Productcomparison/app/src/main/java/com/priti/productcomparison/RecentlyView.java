package com.priti.productcomparison;

import android.app.Activity;

public class RecentlyView extends Activity {
}
