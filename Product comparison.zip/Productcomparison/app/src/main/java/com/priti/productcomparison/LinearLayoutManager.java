package com.priti.productcomparison;

public class LinearLayoutManager {
    public LinearLayoutManager(ComparisonView shoppingCart) {
    }
}
