package com.priti.productcomparison;

import android.os.Parcel;

public class Products {
    public Products(String s, double s1, String v) {

    }

    public int getName() {
        return 0;
    }

    public int getDescription() {
        return 0;
    }

    public Object getPrice() {
        return null;
    }

    public Object getImageUrl() {
        return null;
    }

    private int imageResId;

    // Constructor
    public Products(Parcel imageResId) {
        this.imageResId = imageResId;
    }

    // Getter method for image resource ID
    public int getImageResId() {
        return imageResId;
    }
}
