package com.priti.productcomparison;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public abstract class RecentlyViewed extends AppCompatActivity implements RecentlyViewedAdapter.OnItemClickListener {

    private RecyclerView recentlyViewedRecyclerView;
    private RecentlyViewedAdapter recentlyViewedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recently_viewed);

        recentlyViewedRecyclerView = findViewById(R.id.recentlyViewedRecyclerView);
        recentlyViewedRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Product> recentlyViewedProducts = new ArrayList<>();
        // Populate recentlyViewedProducts with data

        recentlyViewedAdapter = new RecentlyViewedAdapter(this, recentlyViewedProducts);
        recentlyViewedAdapter.setOnItemClickListener(this);
        recentlyViewedRecyclerView.setAdapter(recentlyViewedAdapter);
    }

    @Override
    public void onItemClick(Product product) {
        // Handle item click, navigate to product details screen
        Intent intent = new Intent(this, product_details.class);
        intent.putExtra("product", (Parcelable) product);
        startActivity(intent);
    }
}