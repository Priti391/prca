package com.priti.productcomparison;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

public class ShoppingCart extends AppCompatActivity {

    private RecyclerView shoppingCartRecyclerView; // Declare as RecyclerView
    private ShoppingCartAdapter shoppingCartAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

        // Cast the view obtained from findViewById to a RecyclerView
        shoppingCartRecyclerView = findViewById(R.id.shoppingCartRecyclerView);
        // Call setLayoutManager on shoppingCartRecyclerView
        shoppingCartRecyclerView.setLayoutManager((new LinearLayoutManager(this)));

        // Assuming you have a list of items in the shopping cart, populate the list and set up the adapter
        List<CartItem> cartItems = getCartItems(); // Replace this with your method to get items in the shopping cart
        shoppingCartAdapter = new ShoppingCartAdapter(this, cartItems);
        shoppingCartRecyclerView.setAdapter(shoppingCartAdapter);
    }

    private List<CartItem> getCartItems() {
        // Implement your logic to fetch items in the shopping cart from a database or SharedPreferences
        // For now, we'll create dummy items in the shopping cart for demonstration
        List<CartItem> cartItems = new ArrayList<>();
        cartItems.add(new CartItem("Product 1", 19.99, 2));
        cartItems.add(new CartItem("Product 2", 29.99, 1));
        // Add more items in the shopping cart as needed
        return cartItems;
    }

}