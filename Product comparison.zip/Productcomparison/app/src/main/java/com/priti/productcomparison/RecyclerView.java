package com.priti.productcomparison;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

public class RecyclerView {
    private LinearLayoutManager layoutManager;

    public void setAdapter(ProductAdapter recentlyViewedAdapter) {
    }

    public void setLayoutManager(LinearLayoutManager layoutManager) {
        this.layoutManager = layoutManager;
    }

    public LinearLayoutManager getLayoutManager() {
        return layoutManager;
    }

    public static abstract class Adapter<T> {
        @NonNull
        public abstract UserReview.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType);

        public abstract void onBindViewHolder(@NonNull UserReview.ViewHolder holder, int position);

        public abstract int getItemCount();

        public abstract void onBindViewHolder(@NonNull RecentlyViewedAdapter.ViewHolder holder, int position);
    }

    public class ViewHolder {
        public ViewHolder(View itemView) {

        }
    }
}
