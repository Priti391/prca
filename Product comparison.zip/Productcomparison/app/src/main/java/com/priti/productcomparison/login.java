package com.priti.productcomparison;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;
    private EditText usernameEditText;
    private Button loginButton;
    private TextView registerTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        emailEditText = findViewById(R.id.emailEditText);
        loginButton = findViewById(R.id.loginButton);
        registerTextView = findViewById(R.id.registerTextView);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement login logic here
            }
        });

        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the registration screen
                Intent intent = new Intent(login.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

        private void loginUser() {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // For simplicity, let's assume a hardcoded username and password
            String validUsername = "user";
            String validPassword = "password";

            if (username.equals(validUsername) && password.equals(validPassword)) {
                // Successful login
                Intent intent = new Intent(login.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Invalid credentials
                // You can display a message, show an error dialog, etc.
                // For simplicity, let's display a toast message
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
    }