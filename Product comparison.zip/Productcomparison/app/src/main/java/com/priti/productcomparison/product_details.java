package com.priti.productcomparison;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class product_details extends AppCompatActivity {

    private TextView productNameTextView, productPriceTextView;
    private TextView productSpecificationsTextView, productFeaturesTextView, productAvailabilityTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        // Initialize TextViews
        productNameTextView = findViewById(R.id.productNameTextView);
        productPriceTextView = findViewById(R.id.productPriceTextView);
        productSpecificationsTextView = findViewById(R.id.productSpecificationsTextView);
        productFeaturesTextView = findViewById(R.id.productFeaturesTextView);
        productAvailabilityTextView = findViewById(R.id.productAvailabilityTextView);

        // Get product details from intent or API
        String productName = getIntent().getStringExtra("productName");
        double productPrice = getIntent().getDoubleExtra("productPrice", 0.0);
        String productSpecifications = getIntent().getStringExtra("productSpecifications");
        String productFeatures = getIntent().getStringExtra("productFeatures");
        String productAvailability = getIntent().getStringExtra("productAvailability");

        // Set product details in TextViews
        productNameTextView.setText(productName);
        productPriceTextView.setText(String.format("$%.2f", productPrice));
        productSpecificationsTextView.setText(productSpecifications);
        productFeaturesTextView.setText(productFeatures);
        productAvailabilityTextView.setText(productAvailability);
    }
}