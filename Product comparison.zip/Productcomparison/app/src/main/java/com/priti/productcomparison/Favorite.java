package com.priti.productcomparison;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class Favorite extends AppCompatActivity {

    private RecyclerView favoriteRecyclerView;
    private FavoriteAdapter favoriteAdapter;
    private List<product> favoriteProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        favoriteRecyclerView = findViewById(R.id.favoriteRecyclerView);
        favoriteProducts = new ArrayList<>();

        // Assuming you have a list of favorite products, populate the list
        favoriteProducts.add(new product("Favorite Product 1", 19.99, "https://example.com/product1.jpg"));
        favoriteProducts.add(new product("Favorite Product 2", 29.99, "https://example.com/product2.jpg"));

        // Initialize and set the adapter for RecyclerView
        favoriteAdapter = new FavoriteAdapter(this, favoriteProducts);
        favoriteRecyclerView.setAdapter(favoriteAdapter);
        favoriteRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        favoriteAdapter.setOnItemClickListener(new FavoriteAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                // Handle item click here
                product product = favoriteProducts.get(position);
                Toast.makeText(Favorite.this, "Clicked on: " + product.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}