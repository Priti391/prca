package com.priti.productcomparison;

import android.content.BroadcastReceiver;

public class MyNotificationReceiver extends BroadcastReceiver {
}
