package com.priti.productcomparison;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ComparisonView extends AppCompatActivity {

    private RecyclerView productRecyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparison_view);

        // Initialize RecyclerView and product list
        productRecyclerView = findViewById(R.id.productRecyclerView);
        productList = new ArrayList<>();

        // Initialize and set the adapter for RecyclerView
        productAdapter = new ProductAdapter(ComparisonView.this, productList);
        productRecyclerView.setAdapter(productAdapter);
        productRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fetch real-time product data from APIs
        fetchProductData();
    }

    private void fetchProductData() {
        // Implement logic to fetch real-time product data from different shopping APIs
        // This could involve making HTTP requests to the APIs and parsing the responses
        // For demonstration purposes, we'll add some dummy product data
        productList.add(new Product("Product 1", 19.99, "https://example.com/product1.jpg"));
        productList.add(new Product("Product 2", 29.99, "https://example.com/product2.jpg"));

        // Notify the adapter that the data set has changed
        productAdapter.notifyDataSetChanged();

        // Optionally, handle errors if the data fetching fails
        // For now, let's just display a toast message indicating success
        Toast.makeText(this, "Product data fetched successfully", Toast.LENGTH_SHORT).show();
    }
}