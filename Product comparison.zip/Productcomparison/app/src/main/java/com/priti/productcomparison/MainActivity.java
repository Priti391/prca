package com.priti.productcomparison;

import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements ProductAdapter.OnItemClickListener {

    private EditText searchEditText;
    private RecyclerView productRecyclerView ;
    private ProductAdapter productAdapter;
    private List<product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        productRecyclerView = findViewById(R.id.productRecyclerView);

        // Initialize RecyclerView and product list
        productList = new ArrayList<>();
        productList.add(new product("Product 1", 19.99, "https://example.com/product1.jpg"));
        productList.add(new product("Product 2", 29.99, "https://example.com/product2.jpg"));


        // Initialize and set the adapter for RecyclerView
        productAdapter = new ProductAdapter(this, productList);
        productAdapter.setOnItemClickListener(this); // Set item click l
        productRecyclerView.setAdapter(productAdapter);
        productRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Example: Handling search functionality (replace with your actual implementation)
        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String query = searchEditText.getText().toString().trim();
                // Perform search operation based on the query
                performSearch(query);
                return true;
            }
            return false;
        });
    }

    // Example method for performing search (replace with your actual search logic)
    private void performSearch(String query) {
        // Display a toast message with the search query (replace with your search implementation)
        Toast.makeText(this, "Search query: " + query, Toast.LENGTH_SHORT).show();
    }

    // Handle item click from RecyclerView
    @Override
    public void onItemClick(int position) {
        // Get the selected product
        product selectedProduct = productList.get(position);

        // Create an intent to open ProductDetailsActivity
        Intent intent = new Intent(this, product_details.class);
        // Pass the product details to the ProductDetailsActivity
        intent.putExtra("productName", selectedProduct.getName());
        intent.putExtra("productPrice", (Float) selectedProduct.getPrice());
        // Start the ProductDetailsActivity
        startActivity(intent);
    }
}
