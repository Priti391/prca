public class FavoriteActivity {
}
